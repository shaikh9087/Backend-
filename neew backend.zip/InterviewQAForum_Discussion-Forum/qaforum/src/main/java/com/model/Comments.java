package com.model;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity

public class Comments
{


	@Id

	private int commentsId;
	
	private String content;

	public Comments() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Comments(int commentsId, String content) {
		super();
		this.commentsId = commentsId;
		this.content = content;
	}

	public int getCommentsId() {
		return commentsId;
	}

	public void setCommentsId(int commentsId) {
		this.commentsId = commentsId;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Override
	public String toString() {
		return "Comments [commentsId=" + commentsId + ", content=" + content + "]";
	}
	

}
