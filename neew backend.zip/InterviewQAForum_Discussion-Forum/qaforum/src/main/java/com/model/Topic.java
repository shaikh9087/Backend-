package com.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity

public class Topic
{
	@Id

	private int topicId;
	
	private String title;
	
	 @OneToMany(cascade = CascadeType.ALL)
	 private List<Post> post;
		
	
	
	public Topic() 
	{
		super();
	}



	public Topic(int topicId, String title, List<Post> post) {
		super();
		this.topicId = topicId;
		this.title = title;
		this.post = post;
	}



	public int getTopicId() {
		return topicId;
	}



	public void setTopicId(int topicId) {
		this.topicId = topicId;
	}



	public String getTitle() {
		return title;
	}



	public void setTitle(String title) {
		this.title = title;
	}



	public List<Post> getPost() {
		return post;
	}



	public void setPost(List<Post> post) {
		this.post = post;
	}



	@Override
	public String toString() {
		return "Topic [topicId=" + topicId + ", title=" + title + ", post=" + post + "]";
	}

	
	
}